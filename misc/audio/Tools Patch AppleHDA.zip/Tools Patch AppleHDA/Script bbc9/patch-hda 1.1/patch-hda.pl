#!/usr/bin/perl
# Patch AppleHDA with a user supplied codec id to match an existing codec
# class in the driver.
# When patching, take into account that multiple comparisons may need to
# be adjusted in order to have a successful match.
# Originally based upon the simple perl one liner posted by aschar:
# http://www.projectosx.com/forum/index.php?showtopic=465&view=findpost&p=9687

# Goal is to replace patch_id with target_id in the binary
# 2 matches per architecture:
#  Match1 in AppleHDAFunctionGroupFactory::createAppleHDAFunctionGroup()
#  Match2 in AppleHDAWidgetFactory::createAppleHDAWidget()
# Thus 2 patches are required per codec, or 4 for FAT binaries.

# Version 1.1
# Copyright (c) 2011-2012 B.C. <bcc24x7@gmail.com> (bcc9 at insanelymac.com). 
# All rights reserved.

use Getopt::Long;

#The following comparison tables can be dynamically built by looking at 
# the comparison instructions in the match routines using otool.  For ease 
# of use (no need for the user to install xcode), they are included here. 

my @codec_compares_osx107 = (
    0x1aec87ff,
    0x15ad1974,
    0x8384767f,
    0x1002aa00,
    0x83847680,
    0x10134205,
    0x1002aa01,
    0x10de0006,
    0x10134206,
    0x11d41983,
    0x10ec0884,
    0x10ec0261,
    0x10de003f,
    0x10de0013,
    0x10de0007,
    0x10de000a,
    0x10de000c,
    0x11d41984,
    0x11d4198b,
    0x10ec0262,
    0x10ec0885,
    0x1aec8800,
    0x10de0014,
    0x15ad1975
    );
my @codec_compares_osx108 = (
    0x1aec87ff,
    0x15ad1974,
    0x8384767f,
    0x1002aa00,
    0x83847680,
    0x10134205,
    0x1002aa01,
    0x10de0006,
    0x10134206,
    0x10ec0261,
    0x10de003f,
    0x10ec0884,
    0x10ec0262,
    0x10ec0885,
    0x11d41984,
    0x11d4198b,
    0x15ad1975,
    0x1aec8800,
    );
my @codec_compares = ();
my @ranges = ();

my $debug = 0;
my $matches = 0, $range_matches = 0;

my $file;
my $kext = "AppleHDA";
my $outfile="/tmp/$kext";
my $verbose = 0;

# Read configuration file
sub read_config
{
    my $file = $_[0];
    our $err;
    my $rc;

    # Process the contents of the config file
    $rc = do($file);

    # Check for errors
    if ($@) {
	$::err = "ERROR: Failure compiling '$file' - $@";
    } elsif (! defined($rc)) {
	$::err = "ERROR: Failure reading '$file' - $!";
    } elsif (! $rc) {
	$::err = "ERROR: Failure processing '$file'";
    }
    return ($err);
}

# We want to zero out comparsions that are less than the patch id but greater
# than the target id
sub find_codec_ranges
{
    my $index;
    my $target_id, $patch_id;

    $target_id = $_[0];
    $patch_id = $_[1];
    if ($verbose) {
	if ($#codec_compares eq -1) {
	    printf "No codec range comparisons to check\n";
	} else {
	    printf "Checking %d range comparisons between %x and %x\n",
	    $#codec_compares, $patch_id, $target_id;
	}
    }
    for ($index = 0; $index <= $#codec_compares; $index++) {
	if ($codec_compares[$index] < $patch_id &&
	    $codec_compares[$index] > $target_id) {
	    if ($verbose) {
		printf "Found range comparison %x\n", $codec_compares[$index];
	    }
	    push(@ranges, $codec_compares[$index]);
	} elsif ($codec_compares[$index] eq $target_id ||
		 $codec_compares[$index] eq $patch_id) {
	    #We're done looking
	    last;
	}
    }
    if ($#ranges eq -1) {
	printf "No codec range comparisons require patching\n";
    } else {
	printf "%d codec range comparison(s) to patch\n", $#ranges+1;
    }
}

sub patch_codec
{
    my $codec_to_patch, $target_codec;
    my $range_comparison;

    #Convert all codec ids we will match on to little-endian strings
    $target_codec = pack("l", $_[0]);
    $codec_to_patch = pack("l", $_[1]);
    for ($index = 0; $index <= $#ranges; $index++) {
	$ranges[$index] = pack("l", $ranges[$index]);
    }

    open(my $IN, '<', $file) || die "Cannot open '$file' $!";
    open(my $OUT, '>', $outfile) || die "Cannot open '$outfile' $!";
    while ( <$IN> ) {
	if (s/$codec_to_patch/$target_codec/g) {
	    $matches++;
	}
	#patch range
	for ($index = 0; $index <= $#ranges; $index++) {
	    $range_comparison = $ranges[$index];
	    #We zero out the numeric operand of applicable range comparisons
	    # to make the comparisons always succeed
	    if (s/$range_comparison/\x0\x0\x0\x0/g) {
		$range_matches++;
	    }
	}
	print $OUT $_;
    }
    close $OUT;
    close $IN;
}

sub supported()
{
    printf "Supported codecs:\n";
    printf "Target\t\tPatch\t\tName\n";
    printf "Codec ID\tCodec ID\n";
    printf "-------------------------------------------\n";
    foreach my $codec (@codecs) {
	printf "%x\t%x\t%s\n", $codec->{target_id}, $codec->{patch_id}, $codec->{name};
    }
    printf "\n";
}

# Try to find the OS version in 1 of 3 places:
# First, if the working directory is not /S/L/E, check the kext version
# Second, check /S/L/CoreServices/SystemVersion.plist on the target volume
# Third, check the version of the running system
sub osvers
{
    my $root, $dir, $vers;

    $root = $_[0];
    $dir = $_[1];
    if ($dir ne "/System/Library/Extensions") {
	$kextversfile = $root . $dir . "/" . $kext . ".kext/Contents/version.plist";
	chomp($kextvers = `/usr/libexec/PlistBuddy -c 'Print CFBundleShortVersionString' $kextversfile`);
	if ($verbose) {
	    printf "kext version %s\n", $kextvers;
	}
	if ($kextvers >= "2.3.0") {
	    return("10.8");
	} elsif ($kextvers >= "2.2.5") {
	    return("10.7.5");
	} elsif ($kextvers) {
	    return("10.7");
	}
    }
    chomp($vers = `/usr/libexec/PlistBuddy -c 'Print ProductVersion' $root/System/Library/CoreServices/SystemVersion.plist`);
    if (!$vers) {
	chomp($vers = `sw_vers -productVersion`);
    }
    return($vers);
}

sub main()
{
    my $target_id, $patch_id;
    my $match_expect;
    my $root = "";
    my $sledir = "/System/Library/Extensions";
    my $testonly = 0;
    my $err;

    if ($err = read_config("patch-hda-codecs.pl")) {
	printf(STDERR "%s\n", $err);
	exit(1);
    }
    GetOptions (
        'v+' => \$verbose,
	't' => \$testonly,
        's=s' => \$sledir,
        'r=s' => \$root,	#Volume root
	'o=s' => \$osxvers
	);

    $file = $root . $sledir . "/" . $kext . ".kext/Contents/MacOS/" . $kext;

    if (!$osxvers) {
	$osxvers = osvers($root, $sledir);
    }
    printf "OSX version %s detected\n", $osxvers;
    if ($debug) {
#	$osxvers = "10.7.4";
#	$file = $kext;
#	$desired_codec = 0x111d7675;
	$testonly = 1;
    }
    if ($#ARGV > -1) {
	$desired_codec = $ARGV[0];
	if (hex($desired_codec)) {
	    $desired_codec = hex($desired_codec);
	}
    } else {
	printf "Usage: patch-hda.pl <codec-id>|<codec-name>\n" .
	    "Examples: patch-hda.pl 111d7675\n" .
	    "Examples: patch-hda.pl 'IDT 7675'\n";
	supported();
	if (!$debug) {
	    exit(1);
	}
    }
    $match_expect = 2;
    if ($osxvers < "10.8") {
	# FAT binary with 2 architectures
	$match_expect *= 2;
    }
    if ($osxvers < "10.7.5") {
	@codec_compares = @codec_compares_osx107;
    } else {
	@codec_compares = @codec_compares_osx108;
    }

    $target_id = 0;
    foreach my $codec (@codecs) {
	if ($desired_codec eq $codec->{target_id} ||
	    $desired_codec eq $codec->{name}) {
	    $target_id = $codec->{target_id};
	    $patch_id = $codec->{patch_id};
	    printf "Patching AppleHDA codec %x with %x\n", $patch_id,
	    $target_id;
	    last;
	}
    }
    if (!$target_id) {
	printf "Couldn't find a codec map to apply for '%s'.  Nothing done.\n",
	$ARGV[0];
	supported();
	exit(1);
    }
    find_codec_ranges($target_id, $patch_id);
    for ($index = 0; $index <= $#ranges; $index++) {
	$range_comparison = $ranges[$index];
	printf "Patching range comparison %x\n", $range_comparison;
    }

    patch_codec($target_id, $patch_id);

    if ($matches != $match_expect) {
	if ($matches == 0) {
	    printf "Found no matching codec to patch.  $kext may already be patched\n";
	} else {
	    printf "Unexpected codec match count: %d (%d expected)\n", $matches,
	    $match_expect;
	}
	printf "Aborting with $kext NOT patched\n";
	exit(1);
    }
    if ($#ranges gt -1) {
	$match_expect *= ($#ranges + 1);
	if ($range_matches != $match_expect) {
	    printf "Unexpected codec range match count: %d (%d expected)\n",
	    $range_matches, $match_expect;
	    printf "Aborting with $kext NOT patched\n";
	    exit(1);
	}
    }
    my $uid=`id -u`;

    if (!$testonly) {
	if ($uid != 0) {
	    printf "This script requires superuser access to update $kext\n";
	}
	system("sudo mv $file $file.orig");
	if ($?) {
	    exit(1);
	}
	system("sudo mv $outfile $file");
	if ($?) {
	    exit(1);
	}
	system("sudo chown root:wheel $file");
	if ($?) {
	    exit(1);
	}
	system("sudo chmod 755 $file");
	if ($?) {
	    exit(1);
	}
	system("sudo touch $sledir");
	if ($?) {
	    exit(1);
	}
    }

    printf "$file patched successfully.\n";
}

main();
exit(0);
