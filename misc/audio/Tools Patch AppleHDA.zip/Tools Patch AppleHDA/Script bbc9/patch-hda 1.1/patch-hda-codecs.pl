#!/usr/bin/perl
#
# Table of codec IDs that may be patched into AppleHDA 
# patch-hda.pl uses this table to allow codec id replacement in the AppleHDA
# binary.  In the table, patch_id represents the existing codec in the AppleHDA
# binary, and target_id is the codec for the hardware you wish to add support
# (hardware that is not already supported by AppleHDA automatically).
#
# Copyright (c) 2012 B.C. <bcc24x7@gmail.com> (bcc9 at insanelymac.com). 
# All rights reserved.

#note:
#codecs from HDA wizard:
# http://www.insanelymac.com/forum/index.php?showtopic=266531
#have not been verified
@codecs = (
#per hda wizard
    { name => 'ADI AD2000B',
      target_id => 0x11d4989b,
      patch_id => 0x11d4198b		#ADI 1984B
    },
#per hda wizard
    { name => 'IDT 7603',		#aka 92HD75B3X5
      target_id => 0x111d7603,
      patch_id => 0x11d41984		#ADI 1984
    },
#per hda wizard
    { name => 'IDT 7605',		#aka 92HD81B1X5
      target_id => 0x111d7605,
      patch_id => 0x11d4198b		#ADI 1984B
    },
    { name => 'IDT 7675',		#aka 92HD73C1X5
      target_id => 0x111d7675,
      patch_id => 0x11d41984		#ADI 1984
    },
    { name => 'IDT 76d1',		#aka 92HD87B1
      target_id => 0x111d76d1,
      patch_id => 0x11d41984		#ADI 1984
    },
    { name => 'IDT 76e0',		#aka 92HD91BXX
      target_id => 0x111d76e0,
      patch_id => 0x11d4198b		#ADI 1984B
    },
    { name => 'Realtek ALC269',
      target_id => 0x10ec0269,
      patch_id => 0x11d41984		#ADI 1984
    },
#per mirone23
    { name => 'Realtek ALC270',
      target_id => 0x10ec0270,
      patch_id => 0x11d41984		#ADI 1984
    },
#per mirone23
    { name => 'Realtek ALC272',
      target_id => 0x10ec0272,
      patch_id => 0x11d41984		#ADI 1984
    },
#per hda wizard
    { name => 'Realtek ALC662',
      target_id => 0x10ec0662,
      patch_id => 0x10ec0885		#ALC 885
    },
#per hda wizard
    { name => 'Realtek ALC882',
      target_id => 0x10ec0882,
      patch_id => 0x10ec0885		#ALC 885
    },
#per hda wizard
    { name => 'Realtek ALC883',
      target_id => 0x10ec0883,
      patch_id => 0x10ec0885		#ALC 885
    },
#per mirone23
    { name => 'Realtek ALC887',
      target_id => 0x10ec0887,
      patch_id => 0x11d4198b		#ADI 1984B
    },
#per hda wizard
    { name => 'Realtek ALC888',
      target_id => 0x10ec0888,
      patch_id => 0x10ec0885		#ALC 885
    },
    { name => 'Realtek ALC889',
      target_id => 0x10ec0889,
      patch_id => 0x10ec0885		#ALC 885
    },
#Slice's version
#Timewalker75a says this allows for working audio inputs
#alc885 however avoids some sound assertion errors
    { name => 'Realtek ALC889+inputs' ,
      target_id => 0x10ec0889,
      patch_id => 0x11d41984		#ADI 1984
    },
    { name => 'Realtek ALC892',
      target_id => 0x10ec0892,
      patch_id => 0x10ec0885		#ALC 885
    },
#Works with gigabyte z77mx-d3h
    { name => 'VIA VT2021' ,
      target_id => 0x11060441,
      patch_id => 0x11d41984		#ADI 1984
    },
    );

